// PAGE NAVIGATION LAYOUT
$(document).ready(function () {
    $('.chevLeftDown, .chev').click(function (e) {
        e.stopPropagation(); 
        $(this).closest('li').find('.fa-chevron-right').toggleClass('chevDown');
        $(this).closest('li').find('.dropdown-content').slideToggle();

        // Highlight the clicked section in the navigation
        $('.nav .chevLeftDown').removeClass('active');
        $(this).closest('.chevLeftDown').addClass('active');
    });

    // ACCOUNTS PAGE SECTION 
    $(document).ready(function () {
        // Get the article parameter from the URL
        const urlParams = new URLSearchParams(window.location.search);
        const accountParam = urlParams.get('accounts');

        // Show the corresponding article
        if (accountParam) {
            showAccount(accountParam);
        }

        // Function to show the specified article
        function showAccount(accountId) {
            // Hide all articles
            $('.memberPortal-accounts').removeClass('active');

            // Show the target article
            const targetAccount = $('#' + accountId);
            if (targetAccount.length) {
                targetAccount.addClass('active');
            } else {
                console.error('Account not found:', accountId);
            }
        }
    });

    // LOAN PAGE SECTION
    $(document).ready(function () {
        // Get the article parameter from the URL
        const urlParams = new URLSearchParams(window.location.search);
        const loanParam = urlParams.get('loans');

        // Show the corresponding article
        if (loanParam) {
            showLoan(loanParam);
        }

        // Function to show the specified article
        function showLoan(loanId) {
            // Hide all articles
            $('.memberPortal-loans').removeClass('active');

            // Show the target article
            const targetLoan = $('#' + loanId);
            if (targetLoan.length) {
                targetLoan.addClass('active');
            } else {
                console.error('Loan not found:', loanId);
            }
        }
    });
});


// TOGGLE DOWN SECTIONS
document.addEventListener('DOMContentLoaded', function () {
    const myShowLoans = document.getElementById('showMyLoans');
    const myShowLoansContent = document.getElementById('dropdown-select-toggle');
   
    myShowLoans.addEventListener('click', function () {
        if (myShowLoansContent.style.display === 'none' || myShowLoansContent.style.display === '') {
            myShowLoansContent.style.display = 'block';
            myShowLoans.querySelector('i').className = 'fa fa-chevron-down';
        } else {
            myShowLoansContent.style.display = 'none';
            myShowLoans.querySelector('i').className = 'fa fa-chevron-right';
        }
    });

    myShowLoansContent.addEventListener('click', function(event) {
        const target = event.target.classList.value;
        const iconClicked = event.target.querySelector('i');

        let elementsToDisplay = null;

        if (target === 'toggle-advance') {
            elementsToDisplay = document.getElementsByClassName('my-accountl-adv'); 
        } else if (target === 'toggle-welfare') {
            elementsToDisplay = document.getElementsByClassName('my-accountl-wel'); 
        } else if (target === 'toggle-loan-summary') {
            elementsToDisplay = document.getElementsByClassName('my-accountl-sumy'); 
        } else {
           alert('An Error occured!')
        }

        // Convert HTMLCollection to array
        const elementsArray = Array.from(elementsToDisplay);

        // Toggle display of the selected elements
        elementsArray.forEach(element => {
            if (element.style.display === 'grid') {
                element.style.display = 'none';
                iconClicked.className = 'fa fa-chevron-right';
            } else {
                element.style.display = 'grid';
                iconClicked.className = 'fa fa-chevron-down';
            }
        });
    });  
});



